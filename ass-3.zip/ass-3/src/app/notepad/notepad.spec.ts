import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotepadComponent } from './notepad';

describe('Notepad', () => {
  let component: NotepadComponent;
  let fixture: ComponentFixture<NotepadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NotepadComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NotepadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
